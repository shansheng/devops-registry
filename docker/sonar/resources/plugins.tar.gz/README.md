# Readme

    Copy or download plugins.tar[.gz] to here.


    |-- plugins
    |       |-- backelite-sonar-objective-c-plugin-0.6.1.jar
    |       |-- sonar-auth-github-plugin-1.3.jar
    |       |-- sonar-cobertura-plugin-1.9.1.jar
    |       |-- sonar-csharp-plugin-5.9.0.1001.jar
    |       |-- sonar-css-plugin-3.1.jar
    |       |-- sonar-flex-plugin-2.3.jar
    |       |-- sonar-github-plugin-1.4.0.699.jar
    |       |-- sonar-java-plugin-4.8.0.9441.jar
    |       |-- sonar-javascript-plugin-3.0.0.4962.jar
    |       |-- sonar-l10n-zh-plugin-1.15.jar
    |       |-- sonar-php-plugin-2.10.0.2087.jar
    |       |-- sonar-python-plugin-1.7.0.1195.jar
    |       |-- sonar-scm-git-plugin-1.2.jar
    |       |-- sonar-scm-svn-plugin-1.4.0.522.jar
    |       |-- sonar-web-plugin-2.5.0.476.jar
    |       |-- sonar-xml-plugin-1.4.2.885.jar
    |       |-- ...
    |
