# README

    plugins.tar[.gz]

    |-- plugins
    |       |-- git/
    |       |-- git.jpi
    |       |-- subversion/
    |       |-- subversion.jpi
    |       |-- ...
    |-- ...
    |
